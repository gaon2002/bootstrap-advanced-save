package psj;

//ブラウザ表示用クラス
//入出力操作（ファイル読み書きなど）に関する例外を扱うクラス
import java.io.IOException;
//文字列データを画面に出力（表示）するクラス
import java.io.PrintWriter;

//Servlet処理用クラス
//Servletの処理に関する例外を扱うクラス
import javax.servlet.ServletException;
//Servletを作るのに欠かせないクラス
import javax.servlet.http.HttpServlet;
//HTTP通信のリクエスト用クラス
import javax.servlet.http.HttpServletRequest;
//HTTP通信のレスポンス用クラス
import javax.servlet.http.HttpServletResponse;

public class PracticeAverageServlet extends HttpServlet{
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{
			
			// PrinterWriterクラスのインスタンス（out）は、第2引数のHTTPレスポンスが持つgetWriter()メソッドで生成できる
			PrintWriter out = response.getWriter();
			// ブラウザに文字列を出力する
			out.println("Average Test Scores:" + (100+80+45)/3);
	}
}
