package com.example.samuraitravel.form;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

// レビュー新規入力用フォーム

@Data

public class ReviewInputForm {
	
	// 登録フィールド設定
	
	@NotBlank(message = "評価の星の数を選択してください")
	private String review;
	
	@NotBlank(message = "民宿の尿化コメントを入力してください。")
	private String comment;

}
