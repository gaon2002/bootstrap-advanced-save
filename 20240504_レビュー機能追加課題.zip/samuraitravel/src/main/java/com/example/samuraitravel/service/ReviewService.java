package com.example.samuraitravel.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.samuraitravel.entity.Review;
import com.example.samuraitravel.form.ReviewEditForm;
import com.example.samuraitravel.form.ReviewInputForm;
import com.example.samuraitravel.repository.HouseRepository;
import com.example.samuraitravel.repository.ReviewRepository;
import com.example.samuraitravel.repository.UserRepository;

@Service
public class ReviewService {
	
	private final ReviewRepository reviewRepository;
	
	public ReviewService(ReviewRepository reviewRepository,HouseRepository houseRepository, UserRepository userRepository){
		this.reviewRepository = reviewRepository;
	}
	
//	民宿の評価を新規投稿
	@Transactional
	public void create(ReviewInputForm reviewInputForm) {
		Review review = new Review();
		
		review.setReview(reviewInputForm.getReview());
		review.setComment(reviewInputForm.getComment());
        
        // reviewテーブルの保存
		reviewRepository.save(review);
	}
	
	
//	民宿の評価を編集
	@Transactional
	public void update(ReviewEditForm reviewEditForm) {
		Review review = reviewRepository.getReferenceById(reviewEditForm.getId());
		
		review.setReview(reviewEditForm.getReview());
		review.setComment(reviewEditForm.getComment());
        
        // reviewテーブルの保存
		reviewRepository.save(review);
	}
	
	
}
