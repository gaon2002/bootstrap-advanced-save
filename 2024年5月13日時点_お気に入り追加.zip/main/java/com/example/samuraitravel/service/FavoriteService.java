package com.example.samuraitravel.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.samuraitravel.entity.Favorite;
import com.example.samuraitravel.entity.House;
import com.example.samuraitravel.entity.User;
import com.example.samuraitravel.repository.FavoriteRepository;
import com.example.samuraitravel.repository.HouseRepository;
import com.example.samuraitravel.repository.UserRepository;
import com.example.samuraitravel.security.UserDetailsImpl;

@Service
public class FavoriteService {
	
    @Autowired
    private FavoriteRepository favoriteRepository; // お気に入り情報をデータベースに保存するためのリポジトリ
    private HouseRepository houseRepository;
    private UserRepository userRepository;
    
    public FavoriteService(HouseRepository houseRepository, FavoriteRepository favoriteRepository, UserRepository userRepository) {
    	this.favoriteRepository = favoriteRepository;
        this.houseRepository = houseRepository;
        this.userRepository =  userRepository;
    }

//  ■お気に入り登録
    public void addFavorite(@PathVariable(name = "id") Integer id,@AuthenticationPrincipal UserDetailsImpl userDetailsImpl) {
        // ここでお気に入り情報をデータベースに保存する処理を実装します
        // 例えば、favoriteRepositoryを使用してデータベースに新しいお気に入り情報を登録するなど
    	Favorite favorite = new Favorite();
		Integer userId = Integer.valueOf(userDetailsImpl.getUser().getId());
    	
		House house = houseRepository.getReferenceById(id);
		User user = userRepository.getReferenceById(userId);
		
		favorite.setHouse(house);
		favorite.setUser(user);
    	
        favoriteRepository.save(favorite);
    }
    
//  ■お気に入り登録されているかどうかを判断
	public boolean hasUserAlreadyFavorited(House house, User user) {
		// レビュー情報を取得し、特定の住宅とユーザーに関連するレビューが存在するかどうかを確認するロジックを実装
        Favorite favoriteHouseAndUser = favoriteRepository.findByHouseAndUser(house, user);

        return favoriteHouseAndUser != null; // レビューが存在する場合はtrueを返す
        
	}

}
