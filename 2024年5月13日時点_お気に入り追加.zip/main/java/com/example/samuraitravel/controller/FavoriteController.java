package com.example.samuraitravel.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.samuraitravel.entity.Favorite;
import com.example.samuraitravel.entity.House;
import com.example.samuraitravel.entity.User;
import com.example.samuraitravel.repository.FavoriteRepository;
import com.example.samuraitravel.repository.HouseRepository;
import com.example.samuraitravel.security.UserDetailsImpl;
import com.example.samuraitravel.service.FavoriteService;

@Controller
public class FavoriteController {
	
    @Autowired
    private FavoriteService favoriteService;
    private FavoriteRepository favoriteRepository;
    private final HouseRepository houseRepository;
    
    public FavoriteController(HouseRepository houseRepository, FavoriteRepository favoriteRepository, FavoriteService favoriteService) {
    	this.favoriteService = favoriteService;
        this.favoriteRepository = favoriteRepository;
        this.houseRepository= houseRepository;

    	
    }

//  ■お気に入り登録
    @PostMapping("/houses/{id}/addFavorite")
    public String addFavorite(@PathVariable(name = "id") Integer id, Model model, @AuthenticationPrincipal UserDetailsImpl userDetailsImpl, RedirectAttributes redirectAttributes) {
        House house = houseRepository.getReferenceById(id);
        User user = userDetailsImpl.getUser();
        
        favoriteService.addFavorite(id,userDetailsImpl);
 
        boolean hasUserAlreadyFavorited = favoriteService.hasUserAlreadyFavorited(house, user);
        
        model.addAttribute("hasUserAlreadyFavorited", hasUserAlreadyFavorited);
		model.addAttribute("house", house);
		 
		redirectAttributes.addFlashAttribute("successMessage", "お気に入りに登録しました。");  
		 
		return "redirect:houses/{id}";
    }

//   ■お気に入り一覧表示（10件ずつ表示）
	// favorite/index.html
	@GetMapping("/favorite")
	public String favorite(@AuthenticationPrincipal UserDetailsImpl userDetailsImpl,
			  @PageableDefault(page = 0, size = 10, sort = "id", direction = Direction.ASC) Pageable pageable,
			  Model model) {

		Integer userId = Integer.valueOf(userDetailsImpl.getUser().getId());
		
		// 対象のユーザーに関連するFavoriteエンティティのリストを取得
		List<Favorite> favorites = favoriteRepository.findByUserId(userId);
		
		// Favoriteエンティティから関連するHouseエンティティを取得し、リストに追加
		List<Integer> houseList = new ArrayList<>();
		for (Favorite favorite : favorites) {
		Integer houseId = favorite.getHouse().getId();
		houseList.add(houseId);
		}

		// ➀で作成したリストからhouse_idをマッチングさせて、HouseRepositoryからHouseの情報を取得する
		// 実際にRepositoryのカスタムメソッドを使用して、必要なHouseデータを取得。
		Page<House> housePages = houseRepository.findByIdIn(houseList, pageable);
		
		model.addAttribute("housePages", housePages);
		
		return "favorite/index";
  		
	}
		
	
	// お気に入り解除（DBからも削除する）
		@PostMapping("/houses/{id}/favorite/{favoriteId}/delete")
		// show.htmlで削除が選択されたデータのidを引数で受け取る
		public String delete(@PathVariable(name = "id") Integer id,
							 @PathVariable(name = "favoriteId") Integer favoriteId,
							 @AuthenticationPrincipal UserDetailsImpl userDetailsImpl,
							 RedirectAttributes redirectAttributes,
							 Model model) {
//			favoriteRepositoryを使ってデータのCRUD処理を行う、deleteById(受け取った引数)メソッドで削除
			
			favoriteRepository.deleteById(favoriteId);
			
			redirectAttributes.addFlashAttribute("successMessage", "お気に入りを解除しました。");
			
			return "redirect:/houses/show";
		}
		
}
