package com.example.samuraitravel.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.samuraitravel.entity.House;
import com.example.samuraitravel.entity.Review;
import com.example.samuraitravel.form.ReviewEditForm;
import com.example.samuraitravel.form.ReviewInputForm;
import com.example.samuraitravel.repository.HouseRepository;
import com.example.samuraitravel.repository.ReviewRepository;
import com.example.samuraitravel.repository.UserRepository;
import com.example.samuraitravel.security.UserDetailsImpl;
import com.example.samuraitravel.service.ReviewService;

@Controller
@RequestMapping("houses/{id}/reviews")
public class ReviewController {
	private final ReviewRepository reviewRepository;
	private final ReviewService reviewService;
	private final HouseRepository houseRepository;
	
	public ReviewController(UserRepository userRepository, ReviewRepository reviewRepository, ReviewService reviewService, HouseRepository houseRepository) {
		this.reviewRepository = reviewRepository;
		this.reviewService = reviewService;
		this.houseRepository = houseRepository;
	}
	
	// 民宿レビュー一覧の表示（10件ずつ表示）
	// reviews.html
	@GetMapping
	// @AuthenticationPrincipalアノテーションを使用し、認証されたユーザーの情報をUserDetailsオブジェクトとして受け取る。
	public String review(@PageableDefault(page = 0, size = 10, sort = "id", direction = Direction.ASC) Pageable pageable, @PathVariable(name = "id") Integer id, Model model) {

		// userDetailsImpl.getUser()で、Userエンティティ全体を保持し情報にアクセスできるようになる
		House house = houseRepository.getReferenceById(id);
		
		Page<Review> houseReviews = reviewRepository.findAllByHouse(house, pageable);
		
		model.addAttribute("house", house);
		model.addAttribute("houseReview", houseReviews);
		
		return "reviews/index";
		
	}
		
	
	
	// reviewInput.html
	// レビューの新規投稿：インプット画面から情報を入手し、DBを更新する(ReviewService)
	// メソッド：ビューで入力されたデータをReviewInputFormで受け取る
	@PostMapping("/reviewInput")	//@GetMappingはメソッドとGETの処理を行うURLを紐づける役割。
	public String create(Model model) {
		
		// Modelクラスを使ってViewとコントローラーのデータの橋渡しを作る
		// 第１引数：ビュー側から参照する変数名("houseRegistrationForm")
		// 第２引数：ビューに渡すデータはフォームクラスのインスタンスを渡すことになるため、newを行っている
		//　　フォームクラスを利用するにはコントローラーからビューにそのインスタンスを渡す必要がある
		//　　利用する=ビューのフォーム入力項目とフォームクラスのフィールドを関連付けること
		model.addAttribute("reviewInputForm", new ReviewInputForm());
		
		return "reviews/reviewInput";
		
	}
	
	// reviewEdit.html
	// レビュー更新の元情報を表示する
	@GetMapping("/{reviewId}/reviewEdit")	
	public String edit(@AuthenticationPrincipal UserDetailsImpl userDetailsImpl,@PathVariable(name = "reviewId") Integer reviewId, Model model) {
		// ReviewgetReferenceById()で情報を最新にする。
		Review review = reviewRepository.getReferenceById(reviewId);
		// すでに情報が登録されているため、UserEditFormをインスタンス化し、どこに何の情報を入れるかをクリアにする
		// どこに入れるかはedit.htmlの*{}で指定(表示も入力もできるthymeleaf要素)
		ReviewEditForm reviewEditForm = new ReviewEditForm(review.getId(), review.getScore(), review.getComment());
		
		// 
		model.addAttribute("reviewEditForm", reviewEditForm);
		
		return "reviews/reviewEdit";
	}
	
	
	// reviewEdit.html
	// 更新したレビューを更新するメソッド：エラーがなければ更新情報をuserService(Repositoryを使ってデータ更新)に送信、エラーがあればビューに表示する
	@PostMapping("/{reviewId}/update")
	public String update(@ModelAttribute @Validated ReviewEditForm reviewEditForm, BindingResult bindingResult, RedirectAttributes redirectAttributes) {
		// エラーがあればインプットフォームにエラーを表示する
		
		if(bindingResult.hasErrors()) {
			return "reviews/reviewEdit";
		}
		
		reviewService.update(reviewEditForm);
		redirectAttributes.addFlashAttribute("successMessage", "レビューを編集しました。");
		
		return "redirect:reviews";
	}
	
	
	

	// レビューの削除（DBからも削除する）
	@PostMapping("/{reviewId}/delete")
	// show.htmlで削除が選択されたデータのidを引数で受け取る
	public String delete(@PathVariable(name = "reviewId") Integer reviewId, RedirectAttributes redirectAttributes) {
//		reviewRepositoryを使ってデータのCRUD処理を行う、deleteById(受け取った引数)メソッドで削除
		reviewRepository.deleteById(reviewId);
		
		redirectAttributes.addFlashAttribute("successMessage", "レビューを削除しました。");
		
		return "redirect:reviews";
	}
	
	
}
